function [A,theta] = getaxis_angle(R)
    B=ones(3);
	x = atan2d(R(3,2),R(3,3));
	y = atan2d(-R(3,1), sqrt(R(3,2)^2 + R(3,3)^2));
	z = atan2d(R(2,1), R(1,1));
    Rot=R*B;
    if (R(1,1)== 1)
     
        if((R(1,2)==0) && (R(1,3)==0) && (R(2,1)==0) &&(R(3,1)==0))            
        disp("Rotation axis is X")
        A=R(1:3);
        end
    elseif (R(2,2)== 1)
     
        if((R(1,2)==0) && (R(2,1)==0) && (R(2,3)==0) &&(R(3,2)==0))            
        disp("Rotation axis is Y")
        A=R(2:3);
        end
    elseif (R(3,3)== 1)
     
        if((R(3,1)==0) && (R(3,2)==0) && (R(1,3)==0) &&(R(2,3)==0))            
        disp("Rotation axis is Z")
        A=R(3:3);
        end
    else
        disp("The rotation axis is combined");
    end
    

  disp("Angle is in degrees");
  theta=[x,y,z];
end