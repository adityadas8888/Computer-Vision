function [C_W] = project_points(P_W,R,t)
img_Center = [50, 50, 0];
beta = 200;
alpha = 200;
    A=zeros(3,1);
    D=zeros(1,3);    

    focal= sqrt((img_Center(1)-t(1)^2)+(img_Center(2)-t(2)^2));
    
    P_W = [P_W, ones(10,1)];
    P_W_T=transpose(P_W);    
    H = [focal*alpha, 0, img_Center(1), 0; 0, focal*beta, img_Center(2), 0; 0, 0, 1, 0];
    R = [R, A; D,1];
    T = [eye(3), -t; D, 1];
    
    X = H*R*T*(P_W.');
    X_T=transpose(X(1:2,:));
    C_W=X_T;
end


