P_W = [-1, -0.5, -1; -1, 0.5, -1; 1, 0.5, -1; 1, -0.5, -1; -1, -0.5, 1; -1, 0.5, 1; 1, 0.5, 1; 1, -0.5, 1; -1, 0, 1.5; 1, 0, 1.5;];
house = P_W.';
subplot(2,3,1)
plot3([house(1,1:4) house(1,1)], [house(2,1:4) house(2,1)], [house(3,1:4) house(3,1)],'-o', 'Color','red');
hold on
plot3([house(1,5:8) house(1,5)], [house(2,5:8) house(2,5)], [house(3,5:8) house(3,5)], '-o', 'Color','b');
plot3(house(1,9:10), house(2,9:10), house(3,9:10), '-o', 'Color','red');
plot3([house(1,5) house(1,9)], [house(2,5) house(2,9)], [house(3,5) house(3,9)], '-o', 'Color','red');
plot3([house(1,6) house(1,9)], [house(2,6) house(2,9)], [house(3,6) house(3,9)], '-o', 'Color','red');
plot3([house(1,2) house(1,6)], [house(2,2) house(2,6)], [house(3,2) house(3,6)], '-o', 'Color', 'g');
plot3([house(1,3) house(1,7)], [house(2,3) house(2,7)], [house(3,3) house(3,7)], '-o', 'Color', 'g');
plot3([house(1,7) house(1,10)], [house(2,7) house(2,10)], [house(3,7) house(3,10)], '-o', 'Color','red');
plot3([house(1,8) house(1,10)], [house(2,8) house(2,10)], [house(3,8) house(3,10)], '-o', 'Color','red');
plot3([house(1,1) house(1,5)], [house(2,1) house(2,5)], [house(3,1) house(3,5)], '-o', 'Color', 'g');
plot3([house(1,4) house(1,8)], [house(2,4) house(2,8)], [house(3,4) house(3,8)], '-o', 'Color', 'g');
hold off 

C = [10,10,0; -10,10,0; 0,0,10; 10,0,0; 10,10,10];
for i = 1:1:5
    
    p = [50,50,0];
    c = C(i,:);
    tranX = atan2(norm(cross([0,0,1],(c))),dot([0,0,1],(c)));
    tranY = atan2(norm(-cross([0,1,0],(c))),dot([0,1,0],(c))); 
    tranZ = atan2(norm(cross([1,0,0],(c))),dot([1,0,0],(c)));
    Rotx = [1 0 0; 0 cos(tranX) -sin(tranX); 0 sin(tranX) cos(tranX)];
    Roty = [cos(tranY) 0 sin(tranY); 0 1 0; -sin(tranY) 0 cos(tranY)];
    Rotz = [cos(tranZ) -sin(tranZ) 0; sin(tranZ) cos(tranZ) 0; 0 0 1];

    R = Rotz*Roty*Rotx; 
    
    subplot(2,3,i+1);
    hold on;
    world = project_points(P_W, R, C(i,:).').';
    plot([world(1,5) world(1,9)], [world(2,5) world(2,9)], '-o', 'Color','y');
    plot([world(1,6) world(1,9)], [world(2,6) world(2,9)], '-o', 'Color','y');
    plot([world(1,2) world(1,6)], [world(2,2) world(2,6)], '-o', 'Color', 'g');
    plot([world(1,3) world(1,7)], [world(2,3) world(2,7)], '-o', 'Color', 'g');
    plot([world(1,7) world(1,10)], [world(2,7) world(2,10)], '-o', 'Color','red');
    plot([world(1,8) world(1,10)], [world(2,8) world(2,10)], '-o', 'Color','red');
    plot([world(1,1) world(1,5)], [world(2,1) world(2,5)], '-o', 'Color', 'g');
    plot([world(1,4) world(1,8)], [world(2,4) world(2,8)], '-o', 'Color', 'g');
    plot([world(1,1:4) world(1,1)], [world(2,1:4) world(2,1)],'-o', 'Color','g');
    plot([world(1,5:8) world(1,5)], [world(2,5:8) world(2,5)], '-o', 'Color','b');
    plot(world(1,9:10), world(2,9:10), '-o', 'Color','red');
    title(strcat('Camera at ', mat2str(C(i,:))));
    hold off 
end