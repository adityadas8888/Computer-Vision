L=imread('lines.jpg');
bw=rgb2gray(L);
edtect=edge(bw,'Canny');
[m,n]=size(edtect);
rowmax=sqrt((m*m)+(n*n));
accumulator=zeros(2*rowmax,180);
for i=1:m
    for j=1:n
        if (edtect(i,j)==1)
            for theta=-90:1:89
            rad=theta*(pi/180);
            d=(i*cos(rad))+(j*sin(rad));
            intercept=round(d);
            accumulator(intercept+rowmax+1,theta+90+1)=accumulator(intercept+rowmax+1,theta+90+1)+1;
            end
        end
    end
end
warning('off', 'Images:initSize:adjustingMag');
axis on;
%finding hough peaks
threshold=15;
[maxvalues,ind] = maxk(unique(accumulator(:)), threshold);

maxsiz=size(maxvalues);
indexes=[];
for i=1:maxsiz
    [x,y]=find(accumulator==maxvalues(i));
    indexes(i).X=x(1);
    indexes(i).Y=y(1);
    indexes(i).line1 = [];
    indexes(i).line2 = [];
end

% finding hough lines
for i=1:m
    for j=1:n
        if (edtect(i,j)==1)
            for theta=1:maxsiz
                rad=(indexes(theta).Y-91)*(pi/180);
                d=(i*cos(rad))+(j*sin(rad));
                intercept=round(d);
                    if intercept==(indexes(theta).X-(rowmax+1))
                        if(isempty(indexes(theta).line1))
                            indexes(theta).line1=[i,j];
                        end
                        indexes(theta).line2=[i,j];       
                           
                    end
             end
         end
    end
end

subplot(1,1,1)
imshow(edtect);
hold on;
for i = 1:maxsiz
   if isempty(indexes(i).line1) == 0 && isempty(indexes(i).line2) == 0
         plot([indexes(i).line1(2),indexes(i).line2(2)],[indexes(i).line1(1),indexes(i).line2(1)], 'Color', 'y');
   end
end

hold off;